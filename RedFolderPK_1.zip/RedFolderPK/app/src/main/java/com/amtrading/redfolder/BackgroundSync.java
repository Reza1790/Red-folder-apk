package com.amtrading.redfolder;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Runs about every hour even when the app is closed: downloads ForexFactory + Myfxbook,
 * keeps only high impact news and re-schedules the alerts, so alerts keep coming 24/7.
 */
public class BackgroundSync extends BroadcastReceiver {

    private static final int REQ = 90010;
    private static final String FF1 = "https://nfs.faireconomy.media/ff_calendar_thisweek.json";
    private static final String FF2 = "https://nfs.faireconomy.media/ff_calendar_nextweek.json";
    private static final String MFX = "https://www.myfxbook.com/rss/forex-economic-calendar-events";
    private static final Pattern SPEECH = Pattern.compile(
            "speak|speech|testif|press conference|testimony|hearing|remarks|interview|parliament",
            Pattern.CASE_INSENSITIVE);

    /** Called from app start and after phone reboot. */
    public static void ensureScheduled(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, REQ, new Intent(ctx, BackgroundSync.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + AlarmManager.INTERVAL_HALF_HOUR,
                AlarmManager.INTERVAL_HOUR, pi);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        final Context ctx = context.getApplicationContext();
        final PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                sync(ctx);
            } catch (Throwable ignored) {
            } finally {
                pr.finish();
            }
        }).start();
    }

    static class Ev {
        long t;
        String cur, title;
        boolean speech, ff;
    }

    static void sync(Context ctx) throws Exception {
        SharedPreferences p = ctx.getSharedPreferences("alerts", Context.MODE_PRIVATE);
        JSONObject s = new JSONObject(p.getString("settings", "{}"));
        if (!s.optBoolean("alerts", true)) return;
        int lead = s.optInt("lead", 15);
        String src = s.optString("src", "all");
        boolean speechOnly = s.optBoolean("speechOnly", false);
        JSONArray cursArr = s.optJSONArray("curs");
        List<String> curs = new ArrayList<>();
        if (cursArr != null) for (int i = 0; i < cursArr.length(); i++) curs.add(cursArr.optString(i));

        List<Ev> list = new ArrayList<>();
        boolean any = false;
        if (!"mfx".equals(src)) {
            for (String u : new String[]{FF1, FF2}) {
                try {
                    String body = get(u);
                    if (body == null || !body.trim().startsWith("[")) continue;
                    JSONArray arr = new JSONArray(body);
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.getJSONObject(i);
                        if (!"high".equalsIgnoreCase(o.optString("impact"))) continue;
                        long t = parseIso(o.optString("date"));
                        if (t <= 0) continue;
                        Ev e = new Ev();
                        e.t = t; e.ff = true;
                        e.cur = o.optString("country").toUpperCase(Locale.US);
                        e.title = o.optString("title").trim();
                        list.add(e);
                    }
                    any = true;
                } catch (Exception ignored) {}
            }
        }
        if (!"ff".equals(src)) {
            try {
                String xml = get(MFX);
                if (xml != null && xml.contains("<item")) {
                    any = true;
                    for (Ev m : parseMfx(xml)) {
                        boolean dup = false;
                        for (Ev e : list) {
                            if (e.ff && e.cur.equals(m.cur) && Math.abs(e.t - m.t) <= 10 * 60000L) { dup = true; break; }
                        }
                        if (!dup) list.add(m);
                    }
                }
            } catch (Exception ignored) {}
        }
        if (!any) return; // network failed: keep the alerts that are already set

        long now = System.currentTimeMillis(), leadMs = lead * 60000L;
        TreeMap<Long, List<Ev>> groups = new TreeMap<>();
        for (Ev e : list) {
            e.speech = SPEECH.matcher(e.title).find();
            String c = known(e.cur) ? e.cur : ("ALL".equals(e.cur) ? "ALL" : "OTHER");
            if (!"ALL".equals(c) && !curs.isEmpty() && !curs.contains(c)) continue;
            if (speechOnly && !e.speech) continue;
            if (e.t - leadMs <= now || e.t - now > 8L * 24 * 3600 * 1000) continue;
            List<Ev> g = groups.get(e.t);
            if (g == null) { g = new ArrayList<>(); groups.put(e.t, g); }
            g.add(e);
        }

        SimpleDateFormat tf = new SimpleDateFormat("h:mm a", Locale.US);
        tf.setTimeZone(TimeZone.getTimeZone("Asia/Karachi"));
        JSONArray out = new JSONArray();
        for (Long t : groups.keySet()) {
            List<Ev> g = groups.get(t);
            Ev f = g.get(0);
            StringBuilder body = new StringBuilder();
            for (Ev e : g) body.append(flag(e.cur)).append(' ').append(e.cur).append(" · ").append(e.title).append('\n');
            body.append("⏰ ").append(tf.format(new Date(t))).append(" PKT");
            JSONObject o = new JSONObject();
            o.put("id", "a" + t + "_" + lead);
            o.put("t", t - leadMs);
            o.put("title", "🔴 " + lead + " min: " + f.cur + " " + f.title + (g.size() > 1 ? " +" + (g.size() - 1) : ""));
            o.put("body", body.toString());
            out.put(o);
        }
        AlertScheduler.schedule(ctx, out.toString());
    }

    private static boolean known(String c) {
        return java.util.Arrays.asList("USD", "EUR", "GBP", "JPY", "AUD", "CAD", "NZD", "CHF", "CNY").contains(c);
    }

    private static String flag(String c) {
        switch (c) {
            case "USD": return "🇺🇸";
            case "EUR": return "🇪🇺";
            case "GBP": return "🇬🇧";
            case "JPY": return "🇯🇵";
            case "AUD": return "🇦🇺";
            case "CAD": return "🇨🇦";
            case "NZD": return "🇳🇿";
            case "CHF": return "🇨🇭";
            case "CNY": return "🇨🇳";
            default: return "🌐";
        }
    }

    /** "2026-11-15T16:30:00-05:00" -> epoch ms */
    static long parseIso(String s) {
        try {
            Matcher m = Pattern.compile("(\\d{4})-(\\d{2})-(\\d{2})T(\\d{2}):(\\d{2}):(\\d{2})([+-])(\\d{2}):(\\d{2})").matcher(s);
            if (!m.find()) return -1;
            Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
            c.clear();
            c.set(Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2)) - 1, Integer.parseInt(m.group(3)),
                    Integer.parseInt(m.group(4)), Integer.parseInt(m.group(5)), Integer.parseInt(m.group(6)));
            long off = (Integer.parseInt(m.group(8)) * 60L + Integer.parseInt(m.group(9))) * 60000L;
            return "+".equals(m.group(7)) ? c.getTimeInMillis() - off : c.getTimeInMillis() + off;
        } catch (Exception e) {
            return -1;
        }
    }

    private static final String[] SLUGS = {"united-states", "USD", "euro-area", "EUR", "european-union", "EUR",
            "germany", "EUR", "france", "EUR", "italy", "EUR", "spain", "EUR", "netherlands", "EUR",
            "united-kingdom", "GBP", "japan", "JPY", "australia", "AUD", "canada", "CAD",
            "new-zealand", "NZD", "switzerland", "CHF", "china", "CNY"};

    static List<Ev> parseMfx(String xml) {
        List<Ev> out = new ArrayList<>();
        String[] items = xml.split("<item[\\s>]");
        Pattern pub = Pattern.compile("(\\d{1,2})\\s+(\\w{3})\\s+(\\d{4})\\s+(\\d{1,2}):(\\d{2})");
        String months = "JanFebMarAprMayJunJulAugSepOctNovDec";
        for (int i = 1; i < items.length; i++) {
            String it = items[i];
            String desc = decode(tag(it, "description"));
            if (!desc.toLowerCase(Locale.US).contains("high-impact")) continue;
            String title = decode(tag(it, "title")).trim();
            String link = decode(tag(it, "link")).trim();
            Matcher pm = pub.matcher(tag(it, "pubDate"));
            if (!pm.find()) continue;
            int mon = months.indexOf(pm.group(2)) / 3;
            if (mon < 0) continue;
            Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
            c.clear();
            c.set(Integer.parseInt(pm.group(3)), mon, Integer.parseInt(pm.group(1)),
                    Integer.parseInt(pm.group(4)), Integer.parseInt(pm.group(5)), 0);
            Matcher sm = Pattern.compile("forex-economic-calendar/([^/]+)/").matcher(link);
            String slug = sm.find() ? sm.group(1) : "";
            String cur = "OTHER";
            for (int k = 0; k < SLUGS.length; k += 2) if (SLUGS[k].equals(slug)) cur = SLUGS[k + 1];
            String country = slug.replace('-', ' ');
            String name = title;
            if (!country.isEmpty() && name.toLowerCase(Locale.US).startsWith(country)) name = name.substring(country.length()).trim();
            Ev e = new Ev();
            e.t = c.getTimeInMillis();
            e.cur = cur;
            e.title = name.isEmpty() ? title : name;
            out.add(e);
        }
        return out;
    }

    private static String tag(String s, String name) {
        Matcher m = Pattern.compile("<" + name + "[^>]*>([\\s\\S]*?)</" + name + ">", Pattern.CASE_INSENSITIVE).matcher(s);
        return m.find() ? m.group(1) : "";
    }

    private static String decode(String s) {
        s = s.replaceAll("<!\\[CDATA\\[([\\s\\S]*?)\\]\\]>", "$1");
        Matcher m = Pattern.compile("&#(\\d+);").matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) m.appendReplacement(sb, Matcher.quoteReplacement(String.valueOf((char) Integer.parseInt(m.group(1)))));
        m.appendTail(sb);
        return sb.toString().replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
                .replace("&apos;", "'").replace("&amp;", "&");
    }

    private static String get(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(20000);
        c.setRequestProperty("User-Agent",
                "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36");
        int code = c.getResponseCode();
        if (code >= 400) { c.disconnect(); return null; }
        InputStream in = c.getInputStream();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        c.disconnect();
        return out.toString(StandardCharsets.UTF_8.name());
    }
}
