package com.amtrading.redfolder;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(0xFF07070C);
        web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        web.addJavascriptInterface(new Bridge(), "Native");
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        BackgroundSync.ensureScheduled(this);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.evaluateJavascript("window.onAppResume && window.onAppResume()", null);
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return out.toString(StandardCharsets.UTF_8.name());
    }

    /** Exposed to the page as window.Native */
    public class Bridge {

        /** Native HTTP GET (no CORS limits). Result comes back via window.__nativeCb(id, ok, body). */
        @JavascriptInterface
        public void fetch(final String url, final String id) {
            new Thread(() -> {
                boolean ok;
                String body;
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(25000);
                    c.setInstanceFollowRedirects(true);
                    c.setRequestProperty("User-Agent",
                            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36");
                    c.setRequestProperty("Accept", "application/json, application/xml, text/xml, */*");
                    int code = c.getResponseCode();
                    InputStream in = code < 400 ? c.getInputStream() : c.getErrorStream();
                    body = readAll(in);
                    ok = code < 400;
                    if (!ok) body = "HTTP " + code;
                    c.disconnect();
                } catch (Exception e) {
                    ok = false;
                    body = String.valueOf(e.getMessage());
                }
                final String js = "window.__nativeCb(" + JSONObject.quote(id) + "," + ok + "," + JSONObject.quote(body) + ")";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            }).start();
        }

        /** json = [{id, t (ms epoch), title, body}] */
        @JavascriptInterface
        public void schedule(String json) {
            AlertScheduler.schedule(MainActivity.this, json);
        }

        @JavascriptInterface
        public void cancelAll() {
            AlertScheduler.cancelAll(MainActivity.this);
        }

        @JavascriptInterface
        public void testAlert() {
            AlertReceiver.show(MainActivity.this, 4242, "🔴 Test Alert", "Red folder news alerts are working ✓");
        }

        /** settings JSON (alerts, lead, curs, src, speechOnly) for the background sync */
        @JavascriptInterface
        public void saveSettings(String json) {
            getSharedPreferences("alerts", MODE_PRIVATE).edit().putString("settings", json).apply();
        }

        @JavascriptInterface
        public boolean isNative() {
            return true;
        }
    }
}
