package com.amtrading.redfolder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            AlertScheduler.rescheduleSaved(ctx);
            BackgroundSync.ensureScheduled(ctx);
        }
    }
}
