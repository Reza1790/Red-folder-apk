package com.amtrading.redfolder;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

public final class AlertScheduler {

    private static final String PREFS = "alerts";

    private AlertScheduler() {}

    public static synchronized void schedule(Context ctx, String json) {
        SharedPreferences p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        cancelCodes(ctx, p);
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        Set<String> codes = new HashSet<>();
        long now = System.currentTimeMillis();
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                long t = o.getLong("t");
                if (t <= now) continue;
                int code = o.getString("id").hashCode();
                Intent in = new Intent(ctx, AlertReceiver.class);
                in.putExtra("title", o.optString("title"));
                in.putExtra("body", o.optString("body"));
                in.putExtra("code", code);
                PendingIntent pi = PendingIntent.getBroadcast(ctx, code, in,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
                try {
                    if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
                    else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
                } catch (SecurityException se) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
                }
                codes.add(String.valueOf(code));
            }
        } catch (Exception ignored) {}
        p.edit().putStringSet("codes", codes).putString("last_json", json).apply();
    }

    public static synchronized void cancelAll(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        cancelCodes(ctx, p);
        p.edit().remove("codes").remove("last_json").apply();
    }

    static void rescheduleSaved(Context ctx) {
        String json = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("last_json", null);
        if (json != null) schedule(ctx, json);
    }

    private static void cancelCodes(Context ctx, SharedPreferences p) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        Set<String> codes = p.getStringSet("codes", new HashSet<>());
        for (String c : codes) {
            try {
                PendingIntent pi = PendingIntent.getBroadcast(ctx, Integer.parseInt(c),
                        new Intent(ctx, AlertReceiver.class),
                        PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                if (pi != null) { am.cancel(pi); pi.cancel(); }
            } catch (Exception ignored) {}
        }
    }
}
