# Red Folder PK — Android app

ForexFactory aur Myfxbook ki high-impact (red folder) news aur speeches, Pakistan time (PKT, GMT+5) mein, 3D look ke saath.

## APK kaise banayein (GitHub par free, 5 minute)
1. github.com par login karein, phir **New repository** banayein (private bhi chalegi).
2. Is zip ko extract karein. Phir **uploading an existing file** se saari files aur folders upload karke commit karein.
   (`.github` folder zaroor upload hona chahiye. Agar web upload hidden folder skip kar de to `git push` istemal karein.)
3. **Actions** tab kholein. "Build APK" khud chal jayega, yeh taqreeban 3-4 minute leta hai.
4. Build green hone par us run ko kholein. Neeche **Artifacts** section mein `RedFolderPK-apk` download karein. Us zip ke andar `RedFolderPK.apk` hai.
5. APK phone mein bhej kar install karein. Phone ijazat maange to "Install unknown apps" allow kar dein.

Android Studio ho to: project open karein → Build → Build APK(s).

## Features
- ForexFactory feed (is hafte aur agle hafte ka data) + Myfxbook economic calendar RSS. Sirf High impact events dikhte hain.
- Agar ek hi news dono sites par ho to woh ek card mein merge ho jaati hai, FF + MFX dono badges ke saath.
- Har time PKT mein. Sath mein live clock aur agli red news ka countdown.
- Tabs: Today, Tomorrow, Upcoming, Speeches, Full Week.
- Filters: currency ke hisaab se (Gold ke liye "USD only" preset), source, aur sirf speeches.
- Notifications: news se 5, 10, 15, 30 ya 60 min pehle alert. Phone restart hone ke baad bhi alerts dobara set ho jaate hain.
- Offline cache: internet na ho to aakhri saved data dikhta hai.
